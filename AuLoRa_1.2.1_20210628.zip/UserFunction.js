window.onerror = function(msg, url, ln) {
    if (msg == "This is not an error. This is just to abort javascript")
        return true;
    else
        return false;
    
};
function UserFunction(DeviceName) {
    this.m_Device = DeviceName;
    this.DeviceWidth = function() {
        ExceptionCheck();
        document.getElementById('DeviceWidth').value = this.m_Device;
        document.getElementById('DeviceWidth').click();
        return Number(document.getElementById('retDeviceWidth').value);
    };
}
function SetWait(Time) {
    ExceptionCheck();
    var sTeim = new String(Time);
    document.getElementById('SetWait').value = sTeim;
    document.getElementById('SetWait').click();
}

function SendToLog(Tag, Detail) {
    ExceptionCheck();
    document.getElementById('SendToLog').value = Tag + "|" + Detail;
    document.getElementById('SendToLog').click();
}

function SendSuccessRate(testcase, cntPass, cntFail) {
    ExceptionCheck();
    document.getElementById('SendSuccessRate').value = testcase + "|" + cntPass + "|" + cntFail;
    document.getElementById('SendSuccessRate').click();
}

function SendToReport(StepName, Detail) {
    ExceptionCheck();
    document.getElementById('SendToReport').value = StepName + "|" + Detail;
    document.getElementById('SendToReport').click();
}    

function GetLoopCount() 
{
    ExceptionCheck();
	document.getElementById('GetLoopCount').value = 1;
    document.getElementById('GetLoopCount').click();
	return Number(document.getElementById('retGetLoopCount').value);
}

function ClerVal() 
{
    ExceptionCheck();
	document.getElementById('ClerVal').value = 1;
    document.getElementById('ClerVal').click();
}

function SetVal(Key, Val) 
{
    ExceptionCheck();
	document.getElementById('SetVal').value =  Key + "|" + Val;
    document.getElementById('SetVal').click();
}

function GetVal(Key) 
{
    ExceptionCheck();
	document.getElementById('GetVal').value = Key;
    document.getElementById('GetVal').click();
	return document.getElementById('retGetVal').value;
}

function ToolQuit(Val)
{
	document.getElementById('LoopCountMsg').value = 1; 
	document.getElementById('LoopCountMsg').click();
	
	document.getElementById('End_Execute').value = Val;
	document.getElementById('End_Execute').click();
}

function LineCommand(lineCount){
    document.getElementById('LINE').value = lineCount;
    document.getElementById('LINE').click();
}

function ExceptionCheck() {
    if (Boolean(Number(document.getElementById('Exception').value))) {
        document.getElementById('LoopCountMsg').value = 1; 
        document.getElementById('LoopCountMsg').click();
        document.getElementById('End_Execute').value = 0;
        document.getElementById('End_Execute').click();
        throw new Error('This is not an error. This is just to abort javascript');
    }
}

function ErrorCount(Cnt)
{
	document.getElementById('ErrorCount').value = Cnt;
    document.getElementById('ErrorCount').click();
}


function UsbConnect() 
{
    ExceptionCheck();
	document.getElementById('UsbConnect').value = 1;
    document.getElementById('UsbConnect').click();
    return document.getElementById('retUsbConnect').value;
}

function UsbDisconnect() 
{
    ExceptionCheck();
	document.getElementById('UsbDisconnect').value = 1;
    document.getElementById('UsbDisconnect').click();
    return document.getElementById('retUsbDisconnect').value;
}

function AlertCommand(data){
    document.getElementById('AlertCommand').value = data;
    document.getElementById('AlertCommand').click();
}

function TestStop() 
{
    ExceptionCheck();
	document.getElementById('TestStop').value = 1;
    document.getElementById('TestStop').click();
    return document.getElementById('retTestStop').value;
}

function FileWrite(strPath, strDetail) 
{
    ExceptionCheck();
	document.getElementById('FileWrite').value =  strPath + "|" + strDetail;
    document.getElementById('FileWrite').click();
    return document.getElementById('retFileWrite').value;
}


function SrvOn() {
    ExceptionCheck();
    document.getElementById('SrvOn').value = "Empty";
    document.getElementById('SrvOn').click();
    return document.getElementById('retSrvOn').value;
}

function SrvOff() {
    ExceptionCheck();
    document.getElementById('SrvOff').value = "Empty";
    document.getElementById('SrvOff').click();
    return document.getElementById('retSrvOff').value;
}

function SrvSetLogMode(loglevel) {
    ExceptionCheck();
    document.getElementById('SrvSetLogMode').value = loglevel;
    document.getElementById('SrvSetLogMode').click();
    return document.getElementById('retSrvSetLogMode').value;
}


function SrvSetRFLogMode(loglevel) {
    ExceptionCheck();
    document.getElementById('SrvSetRFLogMode').value = loglevel;
    document.getElementById('SrvSetRFLogMode').click();
    return document.getElementById('retSrvSetRFLogMode').value;
}

function SrvRx2DownNow() {
    ExceptionCheck();
    document.getElementById('SrvRx2DownNow').value = "Empty";
    document.getElementById('SrvRx2DownNow').click();
    return document.getElementById('retSrvRx2DownNow').value;
}

function SrvTxOn() {
    ExceptionCheck();
    document.getElementById('SrvTxOn').value = "Empty";
    document.getElementById('SrvTxOn').click();
    return document.getElementById('retSrvTxOn').value;
}

function SrvTxOff() {
    ExceptionCheck();
    document.getElementById('SrvTxOff').value = "Empty";
    document.getElementById('SrvTxOff').click();
    return document.getElementById('retSrvTxOff').value;
}

function SrvRx2Transmit(Param) {
    ExceptionCheck();
    document.getElementById('SrvRx2Transmit').value = Param;
    document.getElementById('SrvRx2Transmit').click();
    return document.getElementById('retSrvRx2Transmit').value;
}

function SrvSetConfirmed(Param) {
    ExceptionCheck();
    document.getElementById('SrvSetConfirmed').value = Param;
    document.getElementById('SrvSetConfirmed').click();
    return document.getElementById('retSrvSetConfirmed').value;
}

function SrvSetMacData(Type, Data) {
    ExceptionCheck();
    document.getElementById('SrvSetMacData').value = Type + "|" + Data;
    document.getElementById('SrvSetMacData').click();
    return document.getElementById('retSrvSetMacData').value;
}

function SrvSetAppData(Port, Data) {
    ExceptionCheck();
    document.getElementById('SrvSetAppData').value = Port + "|" + Data;
    document.getElementById('SrvSetAppData').click();
    return document.getElementById('retSrvSetAppData').value;
}


function SrvSetParam(Key, Val) {
    ExceptionCheck();
    document.getElementById('SrvSetParam').value =  Key + "|" + Val;
    document.getElementById('SrvSetParam').click();
    return document.getElementById('retSrvSetParam').value;
}


function LoraMaxQueueCount(Count) {
    ExceptionCheck();
    document.getElementById('LoraMaxQueueCount').value =  Count;
    document.getElementById('LoraMaxQueueCount').click();
    return document.getElementById('retLoraMaxQueueCount').value;
}


function LoraPopQueueClear() {
    ExceptionCheck();
    document.getElementById('LoraPopQueueClear').value =  "Empty";
    document.getElementById('LoraPopQueueClear').click();
    return document.getElementById('retLoraPopQueueClear').value;
}



function LoraPopQueueMove() {
    ExceptionCheck();
    document.getElementById('LoraPopQueueMove').value =  "Empty";
    document.getElementById('LoraPopQueueMove').click();
    return document.getElementById('retLoraPopQueueMove').value;
}


function LoraPopQueueCount() {
    ExceptionCheck();
    document.getElementById('LoraPopQueueCount').value =  "Empty";
    document.getElementById('LoraPopQueueCount').click();
    return document.getElementById('retLoraPopQueueCount').value;
}



function LoraMHTType(Index) {
    ExceptionCheck();
    document.getElementById('LoraMHTType').value = Index;
    document.getElementById('LoraMHTType').click();
    return document.getElementById('retLoraMHTType').value;
}

function LoraMic(Index) {
    ExceptionCheck();
    document.getElementById('LoraMic').value = Index;
    document.getElementById('LoraMic').click();
    return document.getElementById('retLoraMic').value;
}

function LoraRxJoin(Index) {
    ExceptionCheck();
    document.getElementById('LoraRxJoin').value = Index;
    document.getElementById('LoraRxJoin').click();
    return document.getElementById('retLoraRxJoin').value;
}

function LoraRxFrmHD(Index) {
    ExceptionCheck();
    document.getElementById('LoraRxFrmHD').value = Index;
    document.getElementById('LoraRxFrmHD').click();
    return document.getElementById('retLoraRxFrmHD').value;
}

function LoraRxMac(Index) {
    ExceptionCheck();
    document.getElementById('LoraRxMac').value = Index;
    document.getElementById('LoraRxMac').click();
    return document.getElementById('retLoraRxMac').value;
}

function LoraRxApp(Index) {
    ExceptionCheck();
    document.getElementById('LoraRxApp').value = Index;
    document.getElementById('LoraRxApp').click();
    return document.getElementById('retLoraRxApp').value;
}


function SrvGetParam(Key) {
    ExceptionCheck();
    document.getElementById('SrvGetParam').value =  Key;
    document.getElementById('SrvGetParam').click();
    return document.getElementById('retSrvGetParam').value;
}


function SrvGetState() {
    ExceptionCheck();
    document.getElementById('SrvGetState').value =  0;
    document.getElementById('SrvGetState').click();
    return document.getElementById('retSrvGetState').value;
}



function GateOn() {
    ExceptionCheck();
    document.getElementById('GateOn').value = "Empty";
    document.getElementById('GateOn').click();
    return document.getElementById('retGateOn').value;
}

function GateOff() {
    ExceptionCheck();
    document.getElementById('GateOff').value = "Empty";
    document.getElementById('GateOff').click();
    return document.getElementById('retGateOff').value;
}


function GateRestart() {
    ExceptionCheck();
    document.getElementById('GateRestart').value = "Empty";
    document.getElementById('GateRestart').click();
    return document.getElementById('retGateRestart').value;
}

function GateSetParam(Key, Val) {
    ExceptionCheck();
    document.getElementById('GateSetParam').value =  Key + "|" + Val;
    document.getElementById('GateSetParam').click();
    return document.getElementById('retGateSetParam').value;
}


function GateGetParam(Key, time) {
    ExceptionCheck();
    document.getElementById('GateGetParam').value =  Key + "|" + time;
    document.getElementById('GateGetParam').click();
    return document.getElementById('retGateGetParam').value;
}


function DevOpen(Port, BitRate) {
    ExceptionCheck();
    document.getElementById('DevOpen').value =  Port + "|" + BitRate;
    document.getElementById('DevOpen').click();
    return document.getElementById('retDevOpen').value;
}


function DevClose() {
    ExceptionCheck();
    document.getElementById('DevClose').value = "Empty";
    document.getElementById('DevClose').click();
    return document.getElementById('retDevClose').value;
}


function DevSetATCmd(AT) {
    ExceptionCheck();
    document.getElementById('DevSetATCmd').value = AT;
    document.getElementById('DevSetATCmd').click();
    return document.getElementById('retDevSetATCmd').value;
}


function DevGetATCmd(AT) {
    ExceptionCheck();
    document.getElementById('DevGetATCmd').value = AT;
    document.getElementById('DevGetATCmd').click();
    return document.getElementById('retDevGetATCmd').value;
}


</script>

